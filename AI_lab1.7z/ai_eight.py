from operator import attrgetter
import node


# function to expand node
def expand_node(expanding_node):
    global nodes_to_expand
    global bad_nodes
    global solution
    res = list()
    # possible ways to move tile depending on its position
    pos_ways = {0: [1, 3], 1: [0, 2, 4], 2: [1, 5], 3: [0, 4, 6], 4: [1, 3, 5, 7],
                5: [2, 4, 8], 6: [3, 7], 7: [4, 6, 8], 8: [5, 7]}
    # determine empty tile position
    pos = expanding_node.layout.index(" ")
    # append new nodes to tree
    for i in pos_ways[pos]:
        new_layout = list(expanding_node.layout)
        new_layout[i], new_layout[pos] = new_layout[pos], new_layout[i]
        new_node = node.Node("".join(ch for ch in new_layout), expanding_node.layout, expanding_node.level + 1)
        if new_node.level == 99999:
            print("Fuck")
        if new_node in solution:
            for n in solution[solution.index(new_node):]:
                if n not in bad_nodes:
                    bad_nodes.append(n)
            solution = solution[:solution.index(new_node)]
        elif new_node not in nodes_to_expand and new_node not in bad_nodes:
            res.append(new_node)
    res = sorted(res, key=attrgetter('wayCost'), reverse=True)
    for n in res:
        nodes_to_expand.append(n)


def find_solution(start, target):
    global nodes_to_expand
    global solution
    global bad_nodes
    nodes_to_expand = node.NodeList()
    solution = node.NodeList()
    bad_nodes = node.NodeList()
    nodes_to_expand.append(start)
    solved = False
    while not solved:
        next_node = nodes_to_expand.pop()
        solution.append(next_node)
        expand_node(next_node)
        for n in nodes_to_expand:
            if n == target:
                print("Solved!")
                solution.append(n)
                solved = True
                break
            # elif n.level == 99:
            #     print("Not solved")
            #     break
    if solved:
        print("Solution :")
        for n in solution:
            print(n)
    else:
        print("No solution or depth level reached 100")


start_layout = node.input_layout("Enter starting layout: ")
target_layout = node.input_layout("Enter target layout: ")
start_node = node.Node(start_layout)
target_node = node.Node(target_layout, level=100000)
find_solution(start_node, target_node)